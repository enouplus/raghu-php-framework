<?php
error_reporting(E_ALL);
ini_set('display_errors', 'On');
date_default_timezone_set('Asia/Kolkata');
define('SITE_ROOT', __DIR__);
define('SITE_URL','https://yoursite.com');
define('THEME_VERSION', microtime(true));

require('vendor/autoload.php');
require('app/system/core.php');
require('app/system/medoo.php');

define('URL', current_url());
define('URL_SEGMENTS', array_slice(explode('/', trim(URL, '/')),2)); 
define('TOTAL_URL_SEGMENTS', count(URL_SEGMENTS));
$db = db_connect('database_name', 'user_name', 'password');


if(TOTAL_URL_SEGMENTS > 1)
{
    if(file_exists(controller_file(URL_SEGMENTS[1])))
    {
        include(controller_file(URL_SEGMENTS[1]));
    }
    else
    {
        display_error_page(404,'PAGE NOT FOUND','The link you followed may be broken, or the page may have been removed.',[
            'button' => [
                'text' => 'BACK TO HOME',
                'url' => site_url()
            ]
        ]);
    }
}
else
{
    include(controller_file('home'));
}
?>