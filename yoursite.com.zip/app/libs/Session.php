<?php 
namespace app\libs;
class Session
{
    private static $isSessionStarted = false;

    public static function start()
    {
       if(self::$isSessionStarted == false)
       {
           session_start();
           self::$isSessionStarted = true;
       }
    }

    public static function get($key)
    {
        return $_SESSION[$key];
    }

    public static function has($key)
    {
        return isset($_SESSION[$key]);
    }

    public static function remove($key)
    {
        unset($_SESSION[$key]);
    }

    public static function set($key,$value)
    {
        $_SESSION[$key] = $value;
    }

    public static function regenerate_id()
    {
        session_regenerate_id();
    }

    public static function destroy()
    {
        if(self::$isSessionStarted == true) {
            session_destroy();
        }
    }

}
?>