<?php
use app\libs\Session;
Session::start();
if(Session::has('admin') && Session::get('admin') == true) 
{
    if(TOTAL_URL_SEGMENTS > 2)
    {
        if(file_exists(controller_file('admin/'.URL_SEGMENTS[2])))
        {
            require(helper_file('form'));
            require(helper_file('request'));
            require(controller_file('admin/'.URL_SEGMENTS[2]));
        }
        else
        {
            display_error_page(404,'PAGE NOT FOUND','The link you followed may be broken, or the page may have been removed.',[
                'button' => [
                    'text' => 'BACK TO ADMIN PANEL',
                    'url' => site_url('admin')
                ]
            ]);
        }
    }
    else
    {
        require (controller_file('admin/home'));
    }
}
else
{
    redirect(site_url('admin-login?redirect='.URL.'?'.http_build_query($_GET)));
}
?>