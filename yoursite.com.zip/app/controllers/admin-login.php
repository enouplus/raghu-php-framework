<?php
use app\libs\Cookie;
use app\libs\Session;
require(helper_file('form'));
require(helper_file('request'));
define('ADMIN_PASSWORD', '9036sgurukuLA');

if(get_get_string('logout') == 'true')
{
    Session::start();
    Cookie::remove('admin_password');
    Session::destroy();
}

if(Cookie::has('admin_password') && Cookie::get('admin_password') === ADMIN_PASSWORD) {
    Session::start();
    Session::regenerate_id();
    Session::set('admin', true);
    if(!empty(get_get_string('redirect'))) {
        redirect(get_get_string('redirect'));
    }
    else {
        redirect(site_url('admin'));
    }
}

if(is_request_method('POST')) {
    if(get_post_string('password') === ADMIN_PASSWORD) {
        Session::start();
        Session::regenerate_id();
        Session::set('admin', true);
        Cookie::set('admin_password', ADMIN_PASSWORD, 60*24*30);
        if(!empty(get_get_string('redirect'))) {
            redirect(get_get_string('redirect'));
        }
        else {
            redirect(site_url('admin'));
        }
    }
    else {
        $login_error = 'Invalid Password';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="<?= assets_url('bootstrap/style.css'); ?>">
    <script src="<?= assets_url('bootstrap/script.js'); ?>"></script>
</head>
<body style="background-color: #f3f3f3;">
    
    <div style="max-width: 400px;" class="mx-auto p-3">
        <div class="shadow-sm p-3 border my-5 bg-white rounded">
            <form action="<?= site_url('admin-login'); ?>" method="post">
                <div style="font-size: 0.8rem;" class="text-danger mb-2"><?= $login_error ?? ''; ?></div>
                <input class="form-control mb-3" placeholder="Password" type="text" name="password" required minlength="8" maxlength="20">
                <button class="btn btn-primary w-100">Login</button>
            </form>
        </div>
    </div>

</body>
</html>