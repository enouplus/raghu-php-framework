<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $code; ?></title>
    <?php
    echo style_tag(assets_url('bootstrap/style.css'),false);
    echo script_tag(assets_url('bootstrap/script.css'),false);
    ?>
</head>
<body class="bg-light">

    <div style="max-width: 90%; width:400px;margin: 2rem;" class="bg-white shadow-sm border p-3 mx-auto">
        <div class="fw-bold p-1" style="font-size: 1.5rem;"><?= $message; ?></div>
        <?php if(!empty($description)) : ?>
        <p class="p-1"><?= $description; ?></p>
        <?php endif; ?>
        <?php if(isset($data['button'])) : ?>
            <a class="btn btn-primary" href="<?= $data['button']['url']; ?>"><?= $data['button']['text']; ?></a>
        <?php endif; ?>
    </div>

</body>
</html>