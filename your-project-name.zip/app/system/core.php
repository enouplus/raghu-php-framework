<?php

use Medoo\Medoo;

function current_url()
{
    $protocol = strtolower($_SERVER['SERVER_PROTOCOL']);
    $protocol = substr($protocol, 0, strpos($protocol, '/'));
    $ssl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on');
    $protocol = ($ssl) ? $protocol . 's' : $protocol;
    $host = $_SERVER['SERVER_NAME'];
    $port = ':' . $_SERVER['SERVER_PORT'];
    $port = (($port == ':80') || ($port == ':443')) ? '' : $port;
    $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    return $protocol . '://' . $host . $port . $uri;
}

function redirect($url)
{
    header('Location: ' . $url);
    exit;
}

function site_url($path = '')
{
    return SITE_URL.$path;
}

function assets_url($path = '')
{
    return SITE_URL.'assets/'.$path;
}

function view_file($path)
{
    return SITE_ROOT.'/app/views/'.$path.'.php';
}

function app_file($path)
{
    return SITE_ROOT.'/app/'.$path.'.php';
}

function filter_file($path)
{
    return SITE_ROOT.'/app/filters/'.$path.'.php';
}

function controller_file($path)
{
    return SITE_ROOT.'/app/controllers/'.$path.'.php';
}

function helper_file($path)
{
    return SITE_ROOT.'/app/helpers/'.$path.'.php';
}

function ajax_response($code,$msg,$desc = '',$data = [])
{
    http_response_code($code);
    exit(json_encode([
        'code' => $code,
        'message' => $msg,
        'description' => $desc,
        'data' => $data
    ]));
}

function db_connect($dbname, $username, $password)
{
    return new Medoo(['database_type' => 'mysql', 'database_name' => $dbname, 'server' => 'localhost', 'username' => $username, 'password' => $password, 'charset' => 'utf8mb4', 'collation' => 'utf8mb4_general_ci', 'error' => PDO::ERRMODE_EXCEPTION]);
}

function display_error_page($code,$message,$description = '',$data = [])
{
    http_response_code($code);
    include(view_file('error'));
    exit;
}

function style_tag($url, $version = THEME_VERSION)
{
    return '<link rel="stylesheet" href="'.$url.(($version === false) ? '' : '?v=').$version.'">';
}

function script_tag($url,$version = THEME_VERSION)
{
    return '<script src="'.$url.(($version === false) ? '' : '?v=').$version.'"></script>';
}