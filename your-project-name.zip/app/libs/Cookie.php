<?php 
namespace app\libs;
class Cookie
{
    public static function get($key)
    {
        return $_COOKIE[$key];
    }

    public static function set($key, $value, $minutes)
    {
        setcookie($key,$value, time() + (60 * $minutes) );
    }
    
    public static function remove($key)
    {
        setcookie($key,'',time() - 3600);
    }

    public static function has($key)
    {
        return isset($_COOKIE[$key]);
    }
}
?>