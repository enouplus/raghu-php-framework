<?php 

function sanitize_slug(string $text,int $max_length = 100, bool $lowercaseOnly = true) : string
{
    $text = substr(trim($text),0,$max_length);
    if($lowercaseOnly) $text = strtolower($text);
    return preg_replace('~-+~', '-', trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $text), '-'));
}

function sanitize_text(string $text) : string
{
    return trim(htmlspecialchars(htmlspecialchars_decode($text)));
}

function sanitize_url(string $url)
{
    return filter_var($url,FILTER_SANITIZE_URL);
}

function sanitize_email(string $email)
{
    return filter_var(trim($email),FILTER_SANITIZE_EMAIL);
}

function sanitize_html(string $html)
{
    return $html;
}

function is_number($numerical_integer)
{
    return (ctype_digit((string)$numerical_integer));
}

function is_email(string $email)
{
    return filter_var($email,FILTER_VALIDATE_EMAIL) ? true : false;
}

function is_url(string $url)
{
    return filter_var($url,FILTER_VALIDATE_URL) ? true : false;
}

function set_value($value,$escape = true)
{
    return ($escape) ? htmlspecialchars($value) : $value;
}
?>