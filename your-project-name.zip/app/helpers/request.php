<?php 
function is_request_method(string $method) : bool
{
    return $_SERVER['REQUEST_METHOD'] == $method;
}

function get_post_string(string $key) : string
{
    return (isset($_POST[$key]) && is_string($_POST[$key])) ? $_POST[$key] : '';
}

function get_get_string(string $key) : string
{
    return (isset($_GET[$key]) && is_string($_GET[$key])) ? $_GET[$key] : '';
}
?>