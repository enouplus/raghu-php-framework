<?php
use app\libs\Session;
header('Content-Type: application/json');
Session::start();
if(Session::has('admin') && Session::get('admin') == true) 
{
    if(TOTAL_URL_SEGMENTS > 2)
    {
        if(file_exists(controller_file('admin-ajax/'.URL_SEGMENTS[2])))
        {
            require(helper_file('form'));
            require(helper_file('request'));
            require(controller_file('admin-ajax/'.URL_SEGMENTS[2]));
        }
        else
        {
            ajax_response(404, 'Route Not Found');
        }
    }
    else
    {
        ajax_response(404, 'Route Not Found');
    }
}
else
{
    ajax_response(401, 'Unauthorized');
}
?>