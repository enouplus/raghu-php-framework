class bsdialog {

    constructor() {

        this.showBody2 = false;

        this.modal = document.createElement('div');
        this.modal.setAttribute('class','modal');

            this.modalDialog = document.createElement('div');
            this.modalDialog.setAttribute('class','modal-dialog');

                // Modal Content
                this.modalContent = document.createElement('div');
                this.modalContent.setAttribute('class','modal-content');

                    // Header
                    this.modalHeader = document.createElement('div');
                    this.modalHeader.setAttribute('class','modal-header');

                        // Title
                        this.modalTitle = document.createElement('h6');
                        this.modalTitle.setAttribute('class','modal-title');
                    
                    this.modalHeader.appendChild(this.modalTitle);

                    // Body
                    this.modalBody = document.createElement('div');
                    this.modalBody.setAttribute('class','modal-body');

                    // Body2
                    this.modalBody2 = document.createElement('div');
                    this.modalBody2.setAttribute('class','modal-body border-top');

                    // Footer
                    this.modalFooter = document.createElement('div');
                    this.modalFooter.setAttribute('class','modal-footer');

                        this.positiveButton = document.createElement('button');
                        this.negativeButton = document.createElement('button');

                        this.modalFooter.appendChild(this.negativeButton);
                        this.modalFooter.appendChild(this.positiveButton);

                this.modalContent.appendChild(this.modalHeader);
                this.modalContent.appendChild(this.modalBody);
                this.modalContent.appendChild(this.modalBody2);
                this.modalContent.appendChild(this.modalFooter);

                this.modalSpinnerContent = document.createElement('div');
                this.modalSpinnerContent.setAttribute('class','modal-content');

                    this.modalSpinnerBody = document.createElement('div');
                    this.modalSpinnerBody.innerHTML = '<div class="modal-body"><div class="d-flex justify-content-center"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div></div></div>';

                    this.modalSpinnerFooter = document.createElement('div');
                    this.modalSpinnerFooter.setAttribute('class','p-2 text-center border-top');

                this.modalSpinnerContent.appendChild(this.modalSpinnerBody);
                this.modalSpinnerContent.appendChild(this.modalSpinnerFooter);

            this.modalDialog.appendChild(this.modalContent);
            this.modalDialog.appendChild(this.modalSpinnerContent);
        
        this.modal.appendChild(this.modalDialog);

        document.body.appendChild(this.modal);
        this._modal = new bootstrap.Modal(this.modal, {
            keyboard: false,
            backdrop: 'static'
        });
    }

    setContent(title, body) {
        if(typeof(title) != 'undefined' && title !== false && title.length > 0) {
            this.modalHeader.style.display = 'block';
            this.modalTitle.innerHTML = title;
        } else {
            this.modalHeader.style.display = 'none';
            this.modalTitle.innerHTML = '';
        }

        if(typeof(body) != 'undefined' && body !== false && body.length > 0) {
            this.modalBody.style.display = 'block';
            this.modalBody.innerHTML = body;
        } else {
            this.modalBody.style.display = 'none';
            this.modalBody.innerHTML = '';
        }
    }

    setPositiveButton(text = false, className = '', onclick = null) {
        if(text !== false) {
            this.positiveButton.innerHTML = text;
            if(className.length > 0) {
                this.positiveButton.setAttribute('class',className);
            } else {
                this.positiveButton.setAttribute('class','btn btn-primary');
            }
            this.positiveButton.onclick = onclick;
            this.positiveButton.style.display = 'inline-block';
        } else {
            this.positiveButton.innerHTML = '';
            this.positiveButton.style.display = 'none';
        }
    }

    setNegativeButton(text = false, className = '', onclick = null) {
        if(text !== false) {
            this.negativeButton.innerHTML = text;
            if(className.length > 0) {
                this.negativeButton.setAttribute('class',className);
            } else {
                this.negativeButton.setAttribute('class','btn btn-secondary');
            }
            this.negativeButton.onclick = onclick;
            this.negativeButton.style.display = 'inline-block';
        } else {
            this.negativeButton.innerHTML = '';
            this.negativeButton.style.display = 'none';
        }
    }

    show() {
        if(this.showBody2 == true) {
            this.modalBody2.style.display = 'block';
        } else {
            this.modalBody2.style.display = 'none';
        }
        this.modalDialog.setAttribute('class','modal-dialog');
        this.modalSpinnerContent.style.display = "none";
        this.modalContent.style.display = "block";
        this._modal.show();
    }

    loading(text = false) {
        this.modalDialog.setAttribute('class','modal-dialog modal-sm');
        this.modalSpinnerContent.style.display = "block";
        this.modalContent.style.display = "none";
        if(text === false) {
            this.modalSpinnerFooter.style.display = 'none';
            this.modalSpinnerFooter.innerHTML = '';
        } else {
            this.modalSpinnerFooter.style.display = 'block';
            this.modalSpinnerFooter.innerHTML = text;
        }
        this._modal.show();
    }

    hide() {
        this._modal.hide();
    }

    setButtons(buttons) {
        if(buttons == false) {
            this.showBody2 = false;
            this.modalBody2.style.display = 'none';
        }
        else {
            this.showBody2 = true;
            buttons.forEach(button => 
            {
                var buttonElement = document.createElement('button');
                buttonElement.setAttribute('class',button.className);
                buttonElement.innerHTML = button.text;
                buttonElement.onclick = button.onclick;
                this.modalBody2.appendChild(buttonElement);
            });
            this.modalBody2.style.display = 'block';
        }
    }
}